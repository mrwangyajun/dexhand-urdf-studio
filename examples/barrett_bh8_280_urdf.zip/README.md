# barrett_bh8_280 — URDF 导出包

由 **DexHand URDF Studio v0.1.0** 生成于 2026-11-12T08:05:59.591Z

## 包内容

```
barrett_bh8_280_urdf.zip
├── robot.urdf          # 机器人描述（9 links / 8 joints）
├── meshes/             # 9 个网格文件（STL/OBJ/DAE 原始文件，未改动）
├── params.json         # 参数原始记录（含原始单位、换算来源）
├── check_urdf.py       # 独立校验脚本（纯 Python 标准库）
└── README.md
```

## 单位与约定

| 量 | 单位 | 说明 |
| --- | --- | --- |
| 长度 | m | 关节 origin、质心、轴向 |
| 质量 | kg | `<mass value>` |
| 角度 | rad | `<origin rpy>` 按 URDF 的固定轴 X-Y-Z（外旋） |
| 惯量 | kg·m² | 相对**质心**，`<inertial><origin>` 即质心 |

- 网格按原始 CAD 坐标导出；若零件网格是 **mm**，`<mesh>` 上带
  `scale="0.001 0.001 0.001"`（RViz / Isaac Sim / MuJoCo 均支持该属性）。
  也可以自行用 Blender/FreeCAD 或 `trimesh` 把网格烘焙成米制后去掉 scale。
- 若某些 link 的惯量来自「输出坐标系」，导出时已用**平行轴定理**换算到质心，
  换算前后数值见 `params.json` 的 `inertiaFrame` 字段。

## 如何在 ROS 2 里检查

```bash
# 0) 无 ROS 环境也能跑：只做结构与物理量静态检查
python3 check_urdf.py robot.urdf

# 1) 有 ROS 2 时用官方工具（urdfdom）
sudo apt install liburdfdom-tools
check_urdf robot.urdf

# 2) 建一个最小功能包并可视化
mkdir -p ~/ros2_ws/src/barrett_bh8_280/urdf
cp -r robot.urdf meshes ~/ros2_ws/src/barrett_bh8_280/urdf/
cd ~/ros2_ws && colcon build --packages-select barrett_bh8_280
source install/setup.bash
ros2 run robot_state_publisher robot_state_publisher \
  --ros-args -p robot_description:="$(cat ~/ros2_ws/src/barrett_bh8_280/urdf/robot.urdf)"
rviz2   # Add -> RobotModel -> Description Topic: /robot_description
```

> 在 RViz 里如果网格是白色/不显示：确认 `meshes/` 与 `robot.urdf` 的相对位置不变，
> 或在 `<mesh filename>` 里改成 `package://` 绝对路径。

## 在 MuJoCo 里加载

```bash
python -c "import mujoco; m = mujoco.MjModel.from_xml_path('robot.urdf'); print(m.nbody, m.njnt)"
```
MuJoCo 会读取 `<mesh scale>`；惯量按 `<inertial>` 使用。若提示 mesh 路径问题，
可在 URDF 同目录执行，或把 `meshes/` 一起放到工作目录。

## 在 Isaac Sim 里加载

`File > Import` 选择 `robot.urdf`（或 `URDF Importer` 扩展），
勾选 *Fix Base Link*（固定基座）后导入即可；网格相对路径会自动解析。
注意 Isaac 默认按米制解析，带 `scale` 的网格会被正确缩放。

## 参数复核建议

1. 打开 `params.json`，核对每个 link 的 `mass` / `com` / `inertia` 与 CAD 质量属性一致。
2. 用 `check_urdf.py` 确认惯量正定、limit 完整、无悬空 link。
3. 在 RViz 里拖动 `joint_state_publisher_gui` 检查关节轴向与限位是否符合预期。
4. 若整机惯量异常（数量级偏大 1e3~1e9 倍），通常是 g·mm² 未换算成 kg·m²。
